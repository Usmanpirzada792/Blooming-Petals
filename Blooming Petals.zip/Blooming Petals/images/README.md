This directory contains images for the Blooming Petals website. All images are from Unsplash.com and are free to use.

Image Credits:
- hero-bg.jpg: Photo by Annie Spratt on Unsplash
- roses.jpg: Photo by Fallon Michael on Unsplash
- bouquets.jpg: Photo by Alisa Anton on Unsplash
- seasonal.jpg: Photo by Mel Poole on Unsplash
- about-hero.jpg: Photo by Jonathan Borba on Unsplash
- behind-scenes-1.jpg: Photo by Sixteen Miles Out on Unsplash
- behind-scenes-2.jpg: Photo by Bench Accounting on Unsplash
- team-1.jpg: Photo by Jonas Kakaroto on Unsplash
- team-2.jpg: Photo by Christian Buehner on Unsplash
- team-3.jpg: Photo by Joseph Gonzalez on Unsplash
